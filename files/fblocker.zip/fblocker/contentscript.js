var div = $("<div />").hide().css({
	position : "fixed",
	top : "0",
	left : "0",
	width : "100%",
	height : "100%",
	backgroundColor : "black",
	opacity : "0.4",
	zIndex : "1000"
}).attr("id", "blackout");
var minidiv = $('<div />').hide().html("[ Locked ]").css({
	position : "fixed",
	width : "100%",
	textAlign : "center",
	color : "#FEFEFE",
	fontSize : "48px",
	zIndex : "1050",
	paddingTop : "200px",
	top : "0",
	left : "0"
}).attr("id", "textoverlay");

var form = $("<form />").html("<input name='code'></input><input type='submit' value='Unlock'></input>");

$(document.body).append(div);
$(document.body).append(minidiv);

var code = 123;
var lockurl = chrome.extension.getURL("lock.png");
var unlockurl = chrome.extension.getURL("unlock.png");
var image = $('<img />').attr('id','lockimg').attr('src',lockurl).css({
	position : "fixed",
	top : "10px",
	right : "20px",
	height : "20px",
	width : "20px",
	zIndex : "1100"
}).click(function() {
	if ($("#lockimg").attr('src')==lockurl) {
		code = prompt("Code", code);
		div.show();
		minidiv.show();
		image.attr('src',unlockurl);
	} else {
		var trycode = prompt("Unlock Code");
		if (trycode == code) {
			div.hide();
			minidiv.hide();
			image.attr('src',lockurl);
		}
	}
});

$(document.body).append(image);
